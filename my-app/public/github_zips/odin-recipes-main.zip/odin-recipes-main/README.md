# odin-recipes
About the project
-This was a basic website mostly using html tags and elements
-Css was used but not into deep, only used it for making changes to the pictures and just to add some styles onto the pictures
-I used some divs so as to structure my some elememts well like on the index.html file, each anchor element i put in a div so that i can use display property of flex to center then unlike having them clustered at the corner
-All in all, this was just a basic website mostly using basic html, no tables or forms were used, jsut simple html elements  