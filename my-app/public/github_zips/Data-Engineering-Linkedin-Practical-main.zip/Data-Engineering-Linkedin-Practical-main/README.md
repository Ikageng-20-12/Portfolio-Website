# Data-Engineering-Linkedin-Practical
Basic ETL Pipeline
